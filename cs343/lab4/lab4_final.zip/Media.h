#ifndef MEDIA_H
#define MEDIA_H

#include <iostream>
#include <string>

class Media 
{

pu
	
 

protected:
  string media;		//Description of Media Type ex. "DVD" or "BLU-RAY"

};

#endif

